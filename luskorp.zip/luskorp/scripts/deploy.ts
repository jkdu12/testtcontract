import { ethers } from "hardhat";
import { MerkleTree } from "merkletreejs";
import keccak256 from "keccak256";
import tokens from "../tokens.json";

async function main() {
  const leaves: Buffer[] = tokens.map((token: any) => keccak256(token.address));
  const merkleTree = new MerkleTree(leaves, keccak256, { sort: true });
  const root: string = merkleTree.getHexRoot();
  const baseURI = "ipfs://cid/";

  const LusKorpERC721A = await ethers.getContractFactory("LusKorpERC721A");
  const luskorperc721a = await LusKorpERC721A.deploy(root, baseURI);

  await luskorperc721a.deployed();

  console.log("Deployed to:", luskorperc721a.address, "(txid:", luskorperc721a.deployTransaction.hash, ")", "with merkle root:", root, "and base URI:", baseURI);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
