import MerkleTree from "merkletreejs";
import keccak256 from "keccak256";
import tokens from "../tokens.json";

interface result {
    root: string;
    proof: string[];
}

const main = async (devAddress: string): Promise<result> => {
    const leaves: Buffer[] = tokens.map((token: any) => keccak256(token.address));
    const tree: MerkleTree = new MerkleTree(leaves, keccak256, { sort: true });
    const root: string = tree.getHexRoot();
    const leaf: Buffer = keccak256(devAddress);
    const proof: string[] = tree.getHexProof(leaf);
    return {
        root: root,
        proof: proof
    };
}

main("0x5B38Da6a701c568545dCfcB03FcB875f56beddC4")
    .then(generationResult => {
        console.log(`Merkle root: ${generationResult.root}`);
        console.log(`Developper merkle proof: ${generationResult.proof}`);
    })
    .catch(console.error);