import { expect } from "chai";
import { ethers } from "hardhat";
import { MerkleTree } from "merkletreejs";
import keccak256 from "keccak256";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import tokens from '../tokens.json';
import { LusKorpERC721A } from "../typechain-types";


describe('Tests Luskorp ERC721A', (): void => {
  let [owner, addr1, addr2, addr3, ...addrs]: SignerWithAddress[] = [];
  let merkleTree: MerkleTree;
  let merkleTreeRoot: string;
  let baseURI: string;
  let contract: LusKorpERC721A;

  before(async (): Promise<void> => {
    [owner, addr1, addr2, addr3, ...addrs] = await ethers.getSigners();
    const leaves: Buffer[] = tokens.map((token: any) => keccak256(token.address));
    merkleTree = new MerkleTree(leaves, keccak256, { sort: true });
    const root: string = merkleTree.getHexRoot();
    merkleTreeRoot = root;
    baseURI = "ips://test/";
  });

  it('Should deploy the smart contract', async (): Promise<void> => {
    const LuskorpERC721A = await ethers.getContractFactory("LusKorpERC721A");
    contract = await LuskorpERC721A.deploy(merkleTreeRoot, baseURI);
  });

  it('sellingStep should equal 0 after deploying the smart contract', async (): Promise<void> => {
    expect(await contract.sellingStep()).to.equal(0);
  });

  it('merkleRoot should be defined and have a length of 66', async (): Promise<void> => {
    expect(await contract.merkleRoot()).to.have.lengthOf(66);
  });

  it('Should NOT change the sellingStep if NOT the owner', async (): Promise<void> => {
    await expect(contract.connect(addr1).setStep(1)).to.be.revertedWith("Ownable: caller is not the owner");
  });

  it('Should set the sale start time', async (): Promise<void> => {
    const newStartTime: number = parseInt((Date.now() / 1000).toFixed(0));
    await contract.setSaleStartTime(newStartTime);
    expect(await contract.saleStartTime()).to.equal(newStartTime);
  });

  it('Should change step to 1 (whitelist sale)', async () => {
    await contract.setStep(1);
    expect(await contract.sellingStep()).to.equal(1);
  });

  it('Should mint one NFT free on the whitelist sale if the user is whitelisted', async (): Promise<void> => {
    const leaf: Buffer = keccak256(addr1.address);
    const proof = merkleTree.getHexProof(leaf);


    await contract.connect(addr1).whitelistMint(addr1.address, 1, proof);
  });

  it('Should get the totalSupply and the total supply should be equalt to 1', async (): Promise<void> => {
    expect(await contract.totalSupply()).to.equal(1);
  });

  it('Should NOT mint one NFT on the whitelist sale if the value is 0', async (): Promise<void> => {
    const leaf: Buffer = keccak256(addr1.address);
    const proof = merkleTree.getHexProof(leaf);


    await expect(contract.connect(addr1).whitelistMint(addr1.address, 1, proof)).to.be.revertedWith("Not enough funds");
  });

  it('Should mint one NFT on the whitelist sale if the user is whitelisted', async (): Promise<void> => {
    const leaf: Buffer = keccak256(addr1.address);
    const proof = merkleTree.getHexProof(leaf);

    const price = await contract.price();

    const overrides = {
      value: price
    };

    await contract.connect(addr1).whitelistMint(addr1.address, 1, proof, overrides);
  });

  it('Should NOT mint one NFT on the whitelist sale if the user is NOT whitelisted', async (): Promise<void> => {
    const leaf: Buffer = keccak256(addr3.address);
    const proof = merkleTree.getHexProof(leaf);

    const price = await contract.price();

    const overrides = {
      value: price
    };

    await expect(contract.connect(addr3).whitelistMint(addr1.address, 1, proof, overrides)).to.be.revertedWith("Not whitelisted");
  });

  it('Should get the totalSupply and the total supply should be equalt to 2', async (): Promise<void> => {
    expect(await contract.totalSupply()).to.equal(2);
  });

  it('Should change the step to 2 (Public sale)', async (): Promise<void> => {
    await contract.setStep(2);
    expect(await contract.sellingStep()).to.equal(2);
  });

  it('Should set the saleStartTime', async (): Promise<void> => {
    const newStartTime: number = parseInt((Date.now() / 1000).toFixed(0)) - 30 * 60 ** 2;
    await contract.setSaleStartTime(newStartTime);
    expect(await contract.saleStartTime()).to.equal(newStartTime);
  });

  it('Should mint one NFT on the public sale', async (): Promise<void> => {
    const price = await contract.price();

    const overrides = {
      value: price
    };

    await expect(contract.mint(owner.address, 1, overrides));
  });

  it('Should get the totalSupply and the total supply should be equalt to 3', async (): Promise<void> => {
    expect(await contract.totalSupply()).to.equal(3);
  });
});